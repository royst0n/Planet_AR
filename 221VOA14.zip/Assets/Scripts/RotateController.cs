using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateController : MonoBehaviour
{
   public GameObject planetObject;
   public Vector3 RotationVector;

    void Update()
    {
       planetObject.transform.Rotate(RotationVector * Time.deltaTime);
    }
}
